def rene_test(stringy):
    return stringy + "some mroe words to show it worked"